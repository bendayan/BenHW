export class coin{
    _typecoin:string;
    _valuecoin:number;
  

    
   
   
    constructor(_typecoin:string,_valuecoin:number){
this._typecoin=_typecoin;
this._valuecoin=_valuecoin;

    } 
}